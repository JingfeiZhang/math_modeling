"""Shared submission helpers."""
